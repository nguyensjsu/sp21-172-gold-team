package com.example.starbucksapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StarbucksApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
