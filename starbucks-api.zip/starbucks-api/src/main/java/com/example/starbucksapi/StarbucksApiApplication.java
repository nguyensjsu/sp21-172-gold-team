package com.example.starbucksapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StarbucksApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(StarbucksApiApplication.class, args);
	}

}
